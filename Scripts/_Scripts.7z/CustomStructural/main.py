import os, shutil
import System
#from System.IO import Directory, Path
import clr
global filepath
import string

#Adding the uniqe ANSYS API's
clr.AddReference("Ans.UI.Toolkit")
clr.AddReference("Ans.UI.Toolkit.Base")
from Ansys.UI.Toolkit import *

def init(context):
	ExtAPI.Log.WriteMessage("Init CustomStructural...")
	return True

def update(task):
	""" Running these lines of code when the update task in WB is activated.
	"""
	ExtAPI.Log.WriteMessage('updating task ' + task.Name)
	#Finding ObjectTest directory in WB project task when Updating.
	if 'Input' in task.Name: 
		ExtAPI.Log.WriteMessage('Input Object found in Group' + task.Properties["GroupName"])
		#system1 = GetSystem(task.Properties["GroupName"])
		system1 = Task.TaskGroup
		setup1 = system1.GetContainer(ComponentName='Setup')
		PropA = task.Properties['SelectInputAPDLFile'].Value #file path
		fpath = PropA.replace(PropA,'\\','/')
		#mapdlInputFile1 = setup1.AddInputFile(FilePath="") #removing peviously set input files 		
		#Setting the filepath in the MAPDL setup, scirpt file is now move to the dp0 directory if the project.
		#changing the directory path seperator - DAMMM Windows
		
		if os.path.isfile(fpath):
			mapdlInputFile1 = setup1.AddInputFile(FilePath=fpath) 
			ExtAPI.Log.WriteMessage('Mapdl Input file set automatically')
			return True
		else:
			ExtAPI.Log.WriteMessage('ERROR: Input file at:' + PropA + 'not found')
			ExtAPI.Log.WriteMessage('Warning: Mapdl Input file not set automatically:')
			return False

def taskinit(task):
	""" Initialing the input task in WB """
	ExtAPI.Log.WriteMessage('Task initialized: ' + task.Name)
	#Setting a node maybe
	#Setting a default path (previous used
	return True

def OnInit(task):
	""" The user has set a input file, on initialling SelectInputAPDLFile		
	"""
	"""
	system1 = Getsystem(Name=task.TaskGroup.Name)
	#system1 = GetSystem(task.Properties["GroupName"])  
	setup1 = system1.GetContainer(ComponentName='Setup')
	PropA = task.Properties['SelectInputAPDLFile'].Value #file path
	#check the localtion of the file 	
	fpath = string.replace(PropA,'\\','/') #changing the directory path seperator - DAMMM Windows
	if os.path.isfile(fpath):
		mapdlInputFile1 = setup1.AddInputFile(FilePath=fpath) 
		ExtAPI.Log.WriteMessage('Mapdl Input file set automatically')
	else:
		ExtAPI.Log.WriteMessage('ERROR: Input file at:' + PropA + 'not found')
		ExtAPI.Log.WriteMessage('Warning: Mapdl Input file not set automatically:')	
	"""
	ExtAPI.Log.WriteMessage('Seleting ADPL File: ' + task.Name)
	return True
	
def OninitOutput(task):
	"""Setting the output path equal to the import - default """
	if 'DataOut' in task.Name: 
		ExtAPI.Log.WriteMessage('Output data Object found in Group' + task.Properties["GroupName"])
		
		#getting the input file path		
		FilePaht_obj = task.TaskGroup.Tasks[0].Properties['SelectInputAPDLFile'] #browsing back to the input file propertie
		OutputDir = os.path.dirname(FilePaht_obj.value)
		Task.Properties['OutputDirectory'] = OutputDir
				
		#copy files
		filters = task.Properties['FileFilter'].Value.split(';')[:-1]
		#filters = [".rst"]		
		#System.IO.Directory.GetFiles(OutputDir)
		#for filter in filters
		#	filter
	return True
		